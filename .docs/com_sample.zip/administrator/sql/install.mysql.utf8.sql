-- $Id: install.mysql.utf8.sql date

-- DROP TABLE IF EXISTS `#__db_table_name`;

-- CREATE TABLE `#__db_table_name` (
--  `id` int(11) NOT NULL auto_increment,
--  `field1_name` varchar(25) NOT NULL,
--   PRIMARY KEY  (`id`)
-- ) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;

