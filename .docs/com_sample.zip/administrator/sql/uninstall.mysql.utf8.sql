-- $Id: uninstall.mysql.utf8.sql date

-- DROP TABLE IF EXISTS `#__db_table_name`;

